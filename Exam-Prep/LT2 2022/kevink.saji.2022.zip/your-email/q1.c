/**
 * Name : Kevin K Saji
 * Email: kevink.saji.2022@scis.smu.edu.sg
 */
#include <stdio.h>
#include <string.h>

char get_winner(char votes[], char candidates[]) {
    int highest_count = 0;
    char highest_candidate = candidates[0];
    for (int i = 0; i < strlen(candidates); i++) {
        int current_count = 0;
        char current_candidate = candidates[i];
        for (int j = 0; j < strlen(votes); j++) {
            if (candidates[i] == votes[j]) {
                current_count++;
            }
            if (current_count > highest_count) {
                highest_count = current_count;
                highest_candidate = current_candidate;
            } else if (current_count == highest_count) {
                if (highest_candidate > current_candidate) {
                    highest_candidate = current_candidate;
                }
            }
        }
    }
    return highest_candidate;
}

int main(void) {
    int tc_num = 1;
    { // test case 1
        char *votes = "BBBTTBBBTT";
        char *candidates = "BT";
        char result = get_winner(votes, candidates);
        printf("Test %d:get_winner(\"%s\",\"%s\")\n", tc_num++, votes, candidates);
        printf("Expected:B\n");
        printf("Actual  :%c\n\n", result);
    }
    { // test case 2
        char *votes = "AABACCCCC";
        char *candidates = "ABC";
        char result = get_winner(votes, candidates);
        printf("Test %d:get_winner(\"%s\",\"%s\")\n", tc_num++, votes, candidates);
        printf("Expected:C\n");
        printf("Actual  :%c\n\n", result);
    }
    { // test case 3
        char *votes = "CCCCCAAAABA";
        char *candidates = "ACBD";
        char result = get_winner(votes, candidates);
        printf("Test %d:get_winner(\"%s\",\"%s\")\n", tc_num++, votes, candidates);
        printf("Expected:A\n");
        printf("Actual  :%c\n\n", result);
    }
}