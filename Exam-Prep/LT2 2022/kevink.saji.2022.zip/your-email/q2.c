/**
 * Name : Kevin K Saji
 * Email: kevink.saji.2022@scis.smu.edu.sg
 */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
// diff between char and int is 48
int digits(unsigned long num) {
    int count  = 0;
    while(num != 0) {
        count++;
        num = num/10;
    }
    return count;
}
char to_char(unsigned long num) {
    return num + 48;
}
char *format(unsigned long num) {
    int num_digits = digits(num);
    int num_commas = num_digits / 3;
    int length = num_digits+ num_commas;
    char *result = calloc(length+1, sizeof(char));
    int iteration = 0;
    for (int i = length-1; i>=0; i--) {
        if (iteration == 3) {
            result[i] = ',';
            iteration = -1;
        } else {
            result[i] = to_char(num%10);
            num = num /10;
        }
        iteration++;
        
        
    }
    
    return result;
}

int main(void) {
    int tc_num = 1;
    {   // Test 1
        long num = 12;
        char *result = format(num);
        printf("Test %d  :format(%ld)\n", tc_num++, num);
        printf("Expected:12\n");
        printf("Actual  :%s\n\n", result);
        free(result);
    }
    {   // Test 2 
        long num = 12345;
        char *result = format(num);
        printf("Test %d  :format(%ld)\n", tc_num++, num);
        printf("Expected:12,345\n");
        printf("Actual  :%s\n\n", result);
        free(result);
    }
    {   // Test 3
        long num = 1234567;
        char *result = format(num);
        printf("Test %d  :format(%ld)\n", tc_num++, num);
        printf("Expected:1,234,567\n");
        printf("Actual  :%s\n\n", result);
        free(result);
    }
}
