/**
 * Name : Kevin K Saji
 * Email: kevink.saji.2022@scis.smu.edu.sg
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
bool is_valid_backspace(char*ptr) {
    if (*ptr == '<' && *(ptr+1) == '-') {
        return true;
    }
    return false;
}
char *erase(char input[]) {
    int length = strlen(input);
    char*result = calloc(length +1, sizeof(char));
    for (int i = 0; i<length-2; i++) {
        if (input[i+1] == '<' && input[i+2]=='-' && input[i]!= '<') {
            i = i+2;
        } else {
            result[i] = input[i];
        }
    }
    return result;
}

int main(void) {
    char *input = "<";
    printf("%d", is_valid_backspace(input));
    int tc_num = 1;
    {   // Test 1
        char *input = "a<-";
        printf("Test %d  :erase(\"%s\")\n", tc_num++, input);
        char *result = erase(input);
        printf("Expected:[]\n");
        printf("Actual  :[%s]\n\n", result);
        free(result);
    }
    {   // Test 2
        char *input = "ab<-<-b";
        printf("Test %d  :erase(\"%s\")\n", tc_num++, input);
        char *result = erase(input);
        printf("Expected:b\n");
        printf("Actual  :%s\n\n", result);
        free(result);
    }
    {   // Test 3
        char *input = "a<<-b";
        printf("Test %d  :erase(\"%s\")\n", tc_num++, input);
        char *result = erase(input);
        printf("Expected:a<-b\n");
        printf("Actual  :%s\n\n", result);
        free(result);
    }
    {   // Test 4
        char *input = "a<<b-c";
        printf("Test %d  :erase(\"%s\")\n", tc_num++, input);
        char *result = erase(input);
        printf("Expected:a<b-c\n");
        printf("Actual  :%s\n\n", result);
        free(result);
    }
    // {   // Test 5
    //     char *input = "<-<<-<<-<-<<-";
    //     printf("Test %d  :erase(\"%s\")\n", tc_num++, input);
    //     char *result = erase(input);
    //     printf("Expected:<-<<-\n");
    //     printf("Actual  :%s\n\n", result);
    //     free(result);
    // }
    // {   // Test 6
    //     char *input = "Hel<-<-<-e<-<-Hel<-l<-lloo<-<<-";
    //     printf("Test %d  :erase(\"%s\")\n", tc_num++, input);
    //     char *result = erase(input);
    //     printf("Expected:Hello<-\n");
    //     printf("Actual  :%s\n\n", result);
    //     free(result);
    // }
}
