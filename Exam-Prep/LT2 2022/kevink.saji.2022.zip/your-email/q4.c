/**
 * Name : Kevin K Saji
 * Email: kevink.saji.2022@scis.smu.edu.sg
 */

#include <ctype.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char *get_cool_username(char name[]) {
    return NULL;
}


int main(void) {
    int tc_num = 1;
    { // Test 1
        char *name = "Ooi Tiong BOH";
        printf("Test %d:get_cool_username(\"%s\")\n", tc_num++, name);
        char *result = get_cool_username(name);
        printf("Expected:abcdefghijklmn_pqrs_uvwxyz\n");
        printf("Actual  :%s\n\n", result);
        free(result);
    }
    { // Test 2
        char *name = "Yi BOH Alan";
        printf("Test %d:get_cool_username(\"%s\")\n", tc_num++, name);
        char *result = get_cool_username(name);
        printf("Expected:z_xwvutsrqponmlkjihgfedcb_\n");
        printf("Actual  :%s\n\n", result);
        free(result);
    }
    { // Test 3
        char *name = "BOH Soh Soh";
        printf("Test %d:get_cool_username(\"%s\")\n", tc_num++, name);
        char *result = get_cool_username(name);
        printf("Expected:abcdefghijklmnopqr__tuvwxyz\n");
        printf("Actual  :%s\n", result);
        free(result);
    }
}