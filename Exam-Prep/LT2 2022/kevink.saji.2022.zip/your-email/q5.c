/**
 * Name : Kevin K Saji
 * Email: kevink.saji.2022@scis.smu.edu.sg
 */

#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct person {
    char name[100];
    char *friend[5];
} person;

typedef struct order {
    person customer;
    char *drink;
    int quantity;
    struct order *next;
} order;

// DO NOT MODIFY THE CODE BELOW!
void print_queue(order *head) {
    while (head != NULL) {
        printf("%s(%d %s) -> ", head->customer.name, head->quantity, head->drink);
        head = head->next;
    }
    puts("NULL");
}

void tompang(order *head) {
    
}

int main(void) {
    int tc_num = 1;
    {   // test 1
        order o5 = {{"p5", {0}}, "black tea", 1, NULL};
        order o4 = {{"p4", {0}}, "oolong tea", 1, &o5};
        order o3 = {{"p3", {"p1"}}, "taro drink", 1, &o4};
        order o2 = {{"p2", {"p1"}}, "taro drink", 1, &o3};
        order o1 = {{"p1", {"p3"}}, "taro drink", 1, &o2};
        printf("Test %d\n", tc_num++);
        printf("Expected:p1(3 taro drink) -> p4(1 oolong tea) -> p5(1 black tea) -> NULL\n");
        tompang(&o1);
        printf("Actual  :");
        print_queue(&o1);
        printf("\n");
    }
    {   // test 2
        order o5 = {{"p5", {"p1", "p2"}}, "taro tea", 1, NULL};
        order o4 = {{"p4", {0}}, "oolong tea", 1, &o5};
        order o3 = {{"p3", {"p1"}}, "matcha", 1, &o4};
        order o2 = {{"p2", {"p1"}}, "taro drink", 1, &o3};
        order o1 = {{"p1", {"p3"}}, "green milk drink", 1, &o2};
        printf("Test %d\n", tc_num++);
        printf("Expected:p1(1 green milk drink) -> p2(1 taro drink) -> p3(1 matcha) -> p4(1 oolong tea) -> p5(1 taro tea) -> NULL\n");
        tompang(&o1);
        printf("Actual  :");
        print_queue(&o1);
        printf("\n");
    }
}